# Avaliação 2º Bim

Resolva a prova alterando os arquivos `Main.java` e `questões/AED2025_2B_Prova.java`.

Para executar, digite:

```
make
```

para testar cada uma das questões 1 a 5:
```
make test_q1
make test_q2
make test_q3
make test_q4
make test_q5
```

para testar todas as questões:
```
make test -k
```

para simular o conceito obtido nas questões e na avaliação:
```
make conceito
```

