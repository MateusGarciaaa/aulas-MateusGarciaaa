package questoes;

import javax.naming.directory.InitialDirContext;
import utils.IO;

public class AED2025_2B_Prova {

    public static int somar(int a, int b) {
        // Variáveis
        int soma;

        // Processamento
        soma = a + b;

        // Retorno do resultado calculado
        return soma;
    }

    public static int calcularPotencia(int b, int e) {
        int potencia = 1;
        for (int i = 0; i < e; i++) {
            potencia = potencia * b;
        }
        return potencia;
    }

    public static int somarMultiplosIntervalo(int x, int a, int b) {
        int soma = 0;
        for (; a <= b; a++) {
            if (a % x == 0) {
                soma = soma + a;
            }
        }
        return soma;
    }

    public static int inverterDigitos(int n) {
        int novo_numero=0;
        while(n>0){
            novo_numero = n%10;
            n=n/10;
            novo_numero = novo_numero+n;
        }
        return novo_numero;
    }

    public static int somarPrimosIntervalo(int a, int b) {
        int somaPrimos = 0;
        for (int indice = a; indice < b; indice++) {
            if (primo(indice) && indice != 1) {
                somaPrimos = somaPrimos + indice;
            }
        }

        return somaPrimos;
    }

    public static boolean primo(int numero) {
        int divisor = 2;
        if (numero <= 1) {
            return false;
        }
        for (int indice = 0; indice < numero; indice++) {
            if (numero % divisor == 0 && divisor < numero) {
                return false;
            }
            divisor++;
        }
        return true;
    }

    public static int obterEnesimoPrimo(int n) {

        int qtdPrimos = 0;
        int contador = 1;

        while (qtdPrimos < n) {
            if (primo(contador)) {
                qtdPrimos++;
            }
            contador++;
        }
        return contador - 1;
    }
}
