import questoes.AED2025_2B_Prova;
import utils.IO;

public class Main {
    public static void main(String[] args) {
        System.out.println("++ Algoritmos e Estruturas de Dados - Prova Prática 2º Bimestre 2025++");
        // questao1();
        // questao2();
         questao3();
        // questao4();
        //questao5();
    }

    // Questão de Exemplo (Já resolvida)
    // Pergunta ao usuário dois números inteiros e imprime a soma deles.
    public static void questao0() {
        // Variáveis
        int a, b, soma;

        // Entrada
        // Valor A
        IO.imprimir("Valor A");
        a = IO.lerValorInteiro();

        // Expoente (e)
        IO.imprimir("Valor B");
        b = IO.lerValorInteiro();

        // Processamento - chamar AED2025_2B_Prova.calcularPotencia
        soma = AED2025_2B_Prova.somar(a, b);

        // Saída
        IO.imprimir("" + a + "+" + b + " = " + soma);
    }

    public static void questao1() {
        // Variáveis
        int base, expoente, potencia;

        // Entrada
        // Base (b)
        IO.imprimir("Base: ");
        base = IO.lerValorInteiro();

        // Expoente (e)
        IO.imprimir("Expoente: ");
        expoente = IO.lerValorInteiro();

        // Processamento - chamar AED2025_2B_Prova.calcularPotencia
        potencia = AED2025_2B_Prova.calcularPotencia(base, expoente);

        // Saída
        IO.imprimir("" + base + "^" + expoente + " = " + potencia);
    }

    public static void questao2() {
        // Variáveis
        int valorUm, inicio, fim, soma;

        // Entrada
        IO.imprimir("Digite o valor do multiplo");
        valorUm = IO.lerValorInteiro();
        IO.imprimir("Digite o valor de inicio");
        inicio = IO.lerValorInteiro();
        IO.imprimir("Digite o valor de fim");
        fim = IO.lerValorInteiro();
        // Processamento - chamar AED2025_2B_Prova.somarMultiplosIntervalo
        soma = AED2025_2B_Prova.somarMultiplosIntervalo(valorUm, inicio, fim);
        // Saída
        IO.imprimir("" + soma);
    }

    public static void questao3() {
        // Variáveis
        int valor = 0;
        int novoValor = 0;
        // Entrada
        IO.imprimir("Digite um valor");
        valor = IO.lerValorInteiro();

        // Processamento - chamar AED2025_2B_Prova.inverterDigitos
        novoValor = AED2025_2B_Prova.inverterDigitos(valor);
        // Saída
        IO.imprimirValorInteiro(novoValor);

    }

    public static void questao4() {
        // Variáveis
        int inicio, fim, somaPrimos;
        // Entrada
        IO.imprimir("Digite um valor de inicio");
        inicio = IO.lerValorInteiro();
        IO.imprimir("Digite um valor de fim");
        fim = IO.lerValorInteiro();
        // Processamento - chamar AED2025_2B_Prova.somarPrimosIntervalo
        somaPrimos = AED2025_2B_Prova.somarPrimosIntervalo(inicio, fim);
        // Saída
        IO.imprimirValorInteiro(somaPrimos);
    }

    public static void questao5() {
        // Variáveis
        int numero, enesimoPrimo;
        // Entrada
        IO.imprimir("Digite um numero");
        numero = IO.lerValorInteiro();
        // Processamento - chamar AED2025_2B_Prova.obterEnesimoPrimo
        enesimoPrimo = AED2025_2B_Prova.obterEnesimoPrimo(numero);
        // Saída
        IO.imprimirValorInteiro(enesimoPrimo);
    }
}
